//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"

var clothes: Dictionary<String,String> = ["Chloe":"Pants", "Rhi":"Shirt", "Tay":"Dresses", "Desi":"Boots"]


for (child, clothing) in clothes {
print("\(child): needs \(clothing)")
}

var shoppingList: [String] = ["Beer", "Steak", "Charcoal"]
shoppingList.append("Cereal")
shoppingList.append("Sugar")



